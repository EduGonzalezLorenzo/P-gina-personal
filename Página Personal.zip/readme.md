- R01: Debido a que el funcionamiento de la página depende de bootstrap este no puede cargarse en segundo plano.

- Página en la que está desplegada la aplicación: http://www.z105.alumnes-esliceu.tk